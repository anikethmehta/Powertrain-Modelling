/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: powertrain_modelling_simulation.c
 *
 * Code generated for Simulink model 'powertrain_modelling_simulation'.
 *
 * Model version                  : 1.35
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Thu Feb 29 21:31:51 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "powertrain_modelling_simulation.h"
#include "rtwtypes.h"
#include "powertrain_modelling_simulation_private.h"
#include "rt_nonfinite.h"

/* Block signals (default storage) */
B_powertrain_modelling_simula_T powertrain_modelling_simulati_B;

/* Continuous states */
X_powertrain_modelling_simula_T powertrain_modelling_simulati_X;

/* Disabled State Vector */
XDis_powertrain_modelling_sim_T powertrain_modelling_simul_XDis;

/* Block states (default storage) */
DW_powertrain_modelling_simul_T powertrain_modelling_simulat_DW;

/* Real-time model */
static RT_MODEL_powertrain_modelling_T powertrain_modelling_simulat_M_;
RT_MODEL_powertrain_modelling_T *const powertrain_modelling_simulat_M =
  &powertrain_modelling_simulat_M_;
real_T look1_pbinlcapw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T prevIndex[], uint32_T maxIndex)
{
  real_T frac;
  real_T y;
  uint32_T bpIdx;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'on'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Clip'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Clip'
     Use previous index: 'on'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    bpIdx = 0U;
    frac = 0.0;
  } else if (u0 < bp0[maxIndex]) {
    uint32_T found;
    uint32_T iLeft;
    uint32_T iRght;

    /* Binary Search using Previous Index */
    bpIdx = prevIndex[0U];
    iLeft = 0U;
    iRght = maxIndex;
    found = 0U;
    while (found == 0U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx - 1U;
        bpIdx = ((bpIdx + iLeft) - 1U) >> 1U;
      } else if (u0 < bp0[bpIdx + 1U]) {
        found = 1U;
      } else {
        iLeft = bpIdx + 1U;
        bpIdx = ((bpIdx + iRght) + 1U) >> 1U;
      }
    }

    frac = (u0 - bp0[bpIdx]) / (bp0[bpIdx + 1U] - bp0[bpIdx]);
  } else {
    bpIdx = maxIndex;
    frac = 0.0;
  }

  prevIndex[0U] = bpIdx;

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'on'
     Overflow mode: 'portable wrapping'
   */
  if (bpIdx == maxIndex) {
    y = table[bpIdx];
  } else {
    real_T yL_0d0;
    yL_0d0 = table[bpIdx];
    y = (table[bpIdx + 1U] - yL_0d0) * frac + yL_0d0;
  }

  return y;
}

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  powertrain_modelling_simulation_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  powertrain_modelling_simulation_step();
  powertrain_modelling_simulation_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  powertrain_modelling_simulation_step();
  powertrain_modelling_simulation_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void powertrain_modelling_simulation_step(void)
{
  if (rtmIsMajorTimeStep(powertrain_modelling_simulat_M)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&powertrain_modelling_simulat_M->solverInfo,
                          ((powertrain_modelling_simulat_M->Timing.clockTick0+1)*
      powertrain_modelling_simulat_M->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(powertrain_modelling_simulat_M)) {
    powertrain_modelling_simulat_M->Timing.t[0] = rtsiGetT
      (&powertrain_modelling_simulat_M->solverInfo);
  }

  {
    real_T lastTime;
    real_T rtb_Switch;
    real_T *lastU;

    /* Lookup_n-D: '<S9>/1-D Lookup Table' incorporates:
     *  Clock: '<S9>/Clock'
     */
    rtb_Switch = look1_pbinlcapw(powertrain_modelling_simulat_M->Timing.t[0],
      powertrain_modelling_sim_ConstP.uDLookupTable_bp01Data,
      powertrain_modelling_sim_ConstP.uDLookupTable_tableData,
      &powertrain_modelling_simulat_DW.m_bpIndex, 2473U);

    /* Gain: '<S5>/km//hr to m//s' incorporates:
     *  UnitConversion: '<S7>/UnitConversion'
     */
    /* Unit Conversion - from: m/s to: km/h
       Expression: output = (3.6*input) + (0) */
    powertrain_modelling_simulati_B.kmhrtoms = 3.5999999999999996 * rtb_Switch *
      0.27777777777777779;

    /* Derivative: '<S17>/Derivative' */
    rtb_Switch = powertrain_modelling_simulat_M->Timing.t[0];
    if ((powertrain_modelling_simulat_DW.TimeStampA >= rtb_Switch) &&
        (powertrain_modelling_simulat_DW.TimeStampB >= rtb_Switch)) {
      rtb_Switch = 0.0;
    } else {
      lastTime = powertrain_modelling_simulat_DW.TimeStampA;
      lastU = &powertrain_modelling_simulat_DW.LastUAtTimeA;
      if (powertrain_modelling_simulat_DW.TimeStampA <
          powertrain_modelling_simulat_DW.TimeStampB) {
        if (powertrain_modelling_simulat_DW.TimeStampB < rtb_Switch) {
          lastTime = powertrain_modelling_simulat_DW.TimeStampB;
          lastU = &powertrain_modelling_simulat_DW.LastUAtTimeB;
        }
      } else if (powertrain_modelling_simulat_DW.TimeStampA >= rtb_Switch) {
        lastTime = powertrain_modelling_simulat_DW.TimeStampB;
        lastU = &powertrain_modelling_simulat_DW.LastUAtTimeB;
      }

      rtb_Switch = (powertrain_modelling_simulati_B.kmhrtoms - *lastU) /
        (rtb_Switch - lastTime);
    }

    /* End of Derivative: '<S17>/Derivative' */

    /* Product: '<S3>/Divide' incorporates:
     *  Constant: '<S15>/Constant'
     *  Constant: '<S16>/Constant'
     *  Constant: '<S17>/Constant'
     *  Constant: '<S18>/Constant'
     *  Constant: '<S18>/Constant1'
     *  Constant: '<S18>/Constant2'
     *  Constant: '<S18>/Constant3'
     *  Constant: '<S3>/Constant'
     *  Constant: '<S3>/Constant1'
     *  Constant: '<S4>/Constant'
     *  Gain: '<S15>/Gain'
     *  Math: '<S18>/Square'
     *  Product: '<S15>/Divide'
     *  Product: '<S16>/Product'
     *  Product: '<S17>/Product'
     *  Product: '<S18>/Product'
     *  Product: '<S3>/Product'
     *  Product: '<S4>/Divide'
     *  Product: '<S4>/Product'
     *  Sum: '<S16>/Add'
     */
    rtb_Switch = ((powertrain_modelling_simulati_B.kmhrtoms *
                   powertrain_modelling_simulati_B.kmhrtoms * 0.5 * 1.225 * 1.1 *
                   0.4 + (powertrain_modelling_sim_ConstB.Product_h +
                          powertrain_modelling_sim_ConstB.Product)) + rtb_Switch
                  * 330.0) * 0.254 / powertrain_modelling_sim_ConstB.Product1 *
      (60.0 * powertrain_modelling_simulati_B.kmhrtoms / 1.5959290680236149 *
       6.0 * 0.10471975511965977) / 0.9;

    /* Switch: '<S1>/Switch' incorporates:
     *  Constant: '<S1>/Constant'
     */
    if (!(rtb_Switch > 0.0)) {
      rtb_Switch = 0.0;
    }

    /* Gain: '<S1>/Gain' incorporates:
     *  Switch: '<S1>/Switch'
     */
    powertrain_modelling_simulati_B.Gain = 1.0526315789473684 * rtb_Switch;

    /* Gain: '<S1>/Gain6' */
    powertrain_modelling_simulati_B.Gain6 = 0.013888888888888888 *
      powertrain_modelling_simulati_B.Gain;
  }

  if (rtmIsMajorTimeStep(powertrain_modelling_simulat_M)) {
    real_T *lastU;

    /* Update for Derivative: '<S17>/Derivative' */
    if (powertrain_modelling_simulat_DW.TimeStampA == (rtInf)) {
      powertrain_modelling_simulat_DW.TimeStampA =
        powertrain_modelling_simulat_M->Timing.t[0];
      lastU = &powertrain_modelling_simulat_DW.LastUAtTimeA;
    } else if (powertrain_modelling_simulat_DW.TimeStampB == (rtInf)) {
      powertrain_modelling_simulat_DW.TimeStampB =
        powertrain_modelling_simulat_M->Timing.t[0];
      lastU = &powertrain_modelling_simulat_DW.LastUAtTimeB;
    } else if (powertrain_modelling_simulat_DW.TimeStampA <
               powertrain_modelling_simulat_DW.TimeStampB) {
      powertrain_modelling_simulat_DW.TimeStampA =
        powertrain_modelling_simulat_M->Timing.t[0];
      lastU = &powertrain_modelling_simulat_DW.LastUAtTimeA;
    } else {
      powertrain_modelling_simulat_DW.TimeStampB =
        powertrain_modelling_simulat_M->Timing.t[0];
      lastU = &powertrain_modelling_simulat_DW.LastUAtTimeB;
    }

    *lastU = powertrain_modelling_simulati_B.kmhrtoms;

    /* End of Update for Derivative: '<S17>/Derivative' */
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(powertrain_modelling_simulat_M)) {
    rt_ertODEUpdateContinuousStates(&powertrain_modelling_simulat_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     */
    ++powertrain_modelling_simulat_M->Timing.clockTick0;
    powertrain_modelling_simulat_M->Timing.t[0] = rtsiGetSolverStopTime
      (&powertrain_modelling_simulat_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.5s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.5, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       */
      powertrain_modelling_simulat_M->Timing.clockTick1++;
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void powertrain_modelling_simulation_derivatives(void)
{
  XDot_powertrain_modelling_sim_T *_rtXdot;
  _rtXdot = ((XDot_powertrain_modelling_sim_T *)
             powertrain_modelling_simulat_M->derivs);

  /* Derivatives for Integrator: '<S6>/Integrator' */
  _rtXdot->Integrator_CSTATE = powertrain_modelling_simulati_B.Gain6;

  /* Derivatives for Integrator: '<S1>/Integrator' */
  _rtXdot->Integrator_CSTATE_d = powertrain_modelling_simulati_B.Gain;
}

/* Model initialize function */
void powertrain_modelling_simulation_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&powertrain_modelling_simulat_M->solverInfo,
                          &powertrain_modelling_simulat_M->Timing.simTimeStep);
    rtsiSetTPtr(&powertrain_modelling_simulat_M->solverInfo, &rtmGetTPtr
                (powertrain_modelling_simulat_M));
    rtsiSetStepSizePtr(&powertrain_modelling_simulat_M->solverInfo,
                       &powertrain_modelling_simulat_M->Timing.stepSize0);
    rtsiSetdXPtr(&powertrain_modelling_simulat_M->solverInfo,
                 &powertrain_modelling_simulat_M->derivs);
    rtsiSetContStatesPtr(&powertrain_modelling_simulat_M->solverInfo, (real_T **)
                         &powertrain_modelling_simulat_M->contStates);
    rtsiSetNumContStatesPtr(&powertrain_modelling_simulat_M->solverInfo,
      &powertrain_modelling_simulat_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&powertrain_modelling_simulat_M->solverInfo,
      &powertrain_modelling_simulat_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&powertrain_modelling_simulat_M->solverInfo,
       &powertrain_modelling_simulat_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&powertrain_modelling_simulat_M->solverInfo,
       &powertrain_modelling_simulat_M->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&powertrain_modelling_simulat_M->solverInfo,
      (boolean_T**) &powertrain_modelling_simulat_M->contStateDisabled);
    rtsiSetErrorStatusPtr(&powertrain_modelling_simulat_M->solverInfo,
                          (&rtmGetErrorStatus(powertrain_modelling_simulat_M)));
    rtsiSetRTModelPtr(&powertrain_modelling_simulat_M->solverInfo,
                      powertrain_modelling_simulat_M);
  }

  rtsiSetSimTimeStep(&powertrain_modelling_simulat_M->solverInfo,
                     MAJOR_TIME_STEP);
  powertrain_modelling_simulat_M->intgData.y =
    powertrain_modelling_simulat_M->odeY;
  powertrain_modelling_simulat_M->intgData.f[0] =
    powertrain_modelling_simulat_M->odeF[0];
  powertrain_modelling_simulat_M->intgData.f[1] =
    powertrain_modelling_simulat_M->odeF[1];
  powertrain_modelling_simulat_M->intgData.f[2] =
    powertrain_modelling_simulat_M->odeF[2];
  powertrain_modelling_simulat_M->contStates = ((X_powertrain_modelling_simula_T
    *) &powertrain_modelling_simulati_X);
  powertrain_modelling_simulat_M->contStateDisabled =
    ((XDis_powertrain_modelling_sim_T *) &powertrain_modelling_simul_XDis);
  powertrain_modelling_simulat_M->Timing.tStart = (0.0);
  rtsiSetSolverData(&powertrain_modelling_simulat_M->solverInfo, (void *)
                    &powertrain_modelling_simulat_M->intgData);
  rtsiSetIsMinorTimeStepWithModeChange
    (&powertrain_modelling_simulat_M->solverInfo, false);
  rtsiSetSolverName(&powertrain_modelling_simulat_M->solverInfo,"ode3");
  rtmSetTPtr(powertrain_modelling_simulat_M,
             &powertrain_modelling_simulat_M->Timing.tArray[0]);
  powertrain_modelling_simulat_M->Timing.stepSize0 = 0.5;

  /* InitializeConditions for Integrator: '<S6>/Integrator' */
  powertrain_modelling_simulati_X.Integrator_CSTATE = 0.0;

  /* InitializeConditions for Derivative: '<S17>/Derivative' */
  powertrain_modelling_simulat_DW.TimeStampA = (rtInf);
  powertrain_modelling_simulat_DW.TimeStampB = (rtInf);

  /* InitializeConditions for Integrator: '<S1>/Integrator' */
  powertrain_modelling_simulati_X.Integrator_CSTATE_d = 0.0;
}

/* Model terminate function */
void powertrain_modelling_simulation_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
