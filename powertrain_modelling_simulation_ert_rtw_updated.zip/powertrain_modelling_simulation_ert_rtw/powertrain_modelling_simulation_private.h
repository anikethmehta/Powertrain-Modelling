/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: powertrain_modelling_simulation_private.h
 *
 * Code generated for Simulink model 'powertrain_modelling_simulation'.
 *
 * Model version                  : 1.35
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Thu Feb 29 21:31:51 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_powertrain_modelling_simulation_private_h_
#define RTW_HEADER_powertrain_modelling_simulation_private_h_
#include "rtwtypes.h"
#include "powertrain_modelling_simulation_types.h"
#include "powertrain_modelling_simulation.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

extern real_T look1_pbinlcapw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T prevIndex[], uint32_T maxIndex);

/* private model entry point functions */
extern void powertrain_modelling_simulation_derivatives(void);

#endif               /* RTW_HEADER_powertrain_modelling_simulation_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
