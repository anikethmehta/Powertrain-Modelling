/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: powertrain_modelling_simulation_types.h
 *
 * Code generated for Simulink model 'powertrain_modelling_simulation'.
 *
 * Model version                  : 1.34
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Thu Feb 22 20:47:50 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_powertrain_modelling_simulation_types_h_
#define RTW_HEADER_powertrain_modelling_simulation_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_powertrain_modelling__T RT_MODEL_powertrain_modelling_T;

#endif                 /* RTW_HEADER_powertrain_modelling_simulation_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
